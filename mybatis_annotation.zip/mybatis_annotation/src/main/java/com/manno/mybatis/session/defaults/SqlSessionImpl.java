package com.manno.mybatis.session.defaults;

import com.manno.dao.UserDao;
import com.manno.mybatis.cfg.Configuration;
import com.manno.mybatis.session.SqlSession;
import com.manno.mybatis.session.proxy.MapperProxy;
import com.manno.utils.DataSourceUtil;


import java.lang.reflect.Proxy;
import java.sql.Connection;
import java.sql.SQLException;

/**
 * Desription
 *
 * @author manno
 * @date 2020/9/26
 */
public class SqlSessionImpl implements SqlSession
{
    private Configuration cfg;
    private Connection connection;

    public SqlSessionImpl(Configuration cfg)
    {
        this.cfg = cfg;
        connection = DataSourceUtil.getConnection(cfg);
        if(connection == null)
        {
            System.out.println("连接数据库失败！");
        }else {
            System.out.println("连接数据库成功！");
        }
    }

    /**
     * @return dao代理对象
     * @author manno
     * @date 2020/9/2
     * @param daoInterfaceClass dao的接口字节码
     * @description
     * 根据参数创建一个代理对象
     */
    public <T> T getMapper(Class<T> daoInterfaceClass)
    {
//        Proxy.newProxyInstance(类加载器,代理对象要实现的接口,如何代理)


        return (T)Proxy.newProxyInstance(daoInterfaceClass.getClassLoader(),
                                               new Class[]{daoInterfaceClass},new MapperProxy(cfg.getMappers(),connection));
    }


    /**
     * @return a
     * @author manno
     * @date 2020/9/26
     * @description
     * 释放资源
     */
    public void close()
    {
        if(connection != null)
        {
            try
            {
                connection.close();
            } catch (SQLException throwables)
            {
                throwables.printStackTrace();
            }
        }


    }
}
