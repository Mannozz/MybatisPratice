package com.manno.mybatis.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Desription
 * 实现mybatis中的@Select注解
 * @author manno
 * @date 2020/9/26
 */

//注解生成器
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface Select
{
    String value();
}
