package com.manno.dao;

import com.manno.domain.User;
import com.manno.mybatis.annotations.Select;


import java.util.List;

/**
 * Desription
 *
 * @author manno
 * @date 2020/9/25
 */
public interface UserDao
{
//    使用注解查询
    @Select("Select * from user")
    List<User> findAll();
}
