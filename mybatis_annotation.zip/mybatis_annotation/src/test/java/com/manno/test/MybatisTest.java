package com.manno.test;

import com.manno.dao.UserDao;
import com.manno.domain.User;
import com.manno.mybatis.io.Resources;
import com.manno.mybatis.session.SqlSession;
import com.manno.mybatis.session.SqlSessionFactory;
import com.manno.mybatis.session.SqlSessionFactoryBuilder;
import com.manno.mybatis.session.defaults.SqlSesssionFactoryImpl;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;


/**
 * Desription
 *  mybatis入门用例
 * @author manno
 * @date 2020/9/25
 */

public class MybatisTest
{
    public static void main(String[] args) throws IOException, InstantiationException, IllegalAccessException
    {
        //读取配置文件
        InputStream inputStream = Resources.getResourceAsStream("SqlMapConfig.xml");
        //创建SqlSessionFactory工厂
        SqlSessionFactoryBuilder builder = new SqlSessionFactoryBuilder();
        SqlSessionFactory factory = builder.build(inputStream);
        //使用工厂生产SqlSession对象
        SqlSession sqlSession = factory.openSession();
        //使用SqlSession创建Dao接口的代理对象

        UserDao userDao = sqlSession.getMapper(UserDao.class);
        //使用代理对象执行方法

//        if(userDao == null)
//        {
//            System.out.println("!");
//        }
        List<User> users = userDao.findAll();
        for (User user: users
             )
        {
            System.out.println(user);
        }
//        System.out.println(userDao.toString());
        //释放资源
        inputStream.close();
    }
}
