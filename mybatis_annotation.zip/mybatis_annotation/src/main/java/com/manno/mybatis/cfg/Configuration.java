package com.manno.mybatis.cfg;

import lombok.Data;

import java.util.HashMap;
import java.util.Map;

/**
 * Desription
 * 包含连接数据库用的信息、要执行的SQL语句以及封装的结果类型
 * @author manno
 * @date 2020/9/26
 */

@Data
public class Configuration
{
    private String driver;
    private String url;

    public void setMappers(Map<String, Mapper> mappers)
    {
        this.mappers.putAll(mappers);//此处需要使用追加方式
    }

    private String username;
    private String password;
    private Map<String,Mapper> mappers = new HashMap<String, Mapper>();
}
