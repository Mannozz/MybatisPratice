package com.manno.mybatis.session.defaults;

import com.manno.mybatis.cfg.Configuration;
import com.manno.mybatis.session.SqlSession;
import com.manno.mybatis.session.SqlSessionFactory;

/**
 * Desription
 * SqlSesssionFactory接口实现类
 * @author manno
 * @date 2020/9/26
 *
 */
public class SqlSesssionFactoryImpl implements SqlSessionFactory
{
    private Configuration cfg;

    public SqlSesssionFactoryImpl(Configuration cfg)
    {
        this.cfg = cfg;
    }

    /**
     * @author manno
     * @date 2020/9/2
     * @description
     * 用于打开一个新的SqlSession对象
     */
    public SqlSession openSession()
    {
        return new SqlSessionImpl(cfg);
    }
}
