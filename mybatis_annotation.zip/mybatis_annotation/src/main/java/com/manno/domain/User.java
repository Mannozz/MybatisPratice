package com.manno.domain;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * Desription
 *
 * @author manno
 * @date 2020/9/25
 */

//lombok的@Data注解在类上；
// 提供类所有属性的 get 和 set 方法，此外还提供了equals、canEqual、hashCode、toString 方法。
@Data
public class User implements Serializable
{
//    ORM原则
    private Integer id;
    private String username;
    private Date birthday;
    private String sex;
    private String address;


}
