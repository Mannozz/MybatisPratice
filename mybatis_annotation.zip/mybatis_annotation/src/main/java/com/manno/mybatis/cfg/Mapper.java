package com.manno.mybatis.cfg;

import lombok.Data;

/**
 * Desription
 *
 * @author manno
 * @date 2020/9/26
 */
@Data
public class Mapper
{
    private String queryString;
    private String resultType;


}
