package com.manno.mybatis.session;

import com.manno.mybatis.cfg.Configuration;
import com.manno.mybatis.session.defaults.SqlSesssionFactoryImpl;
import com.manno.utils.XMLConfigBuilder;
import com.manno.mybatis.session.SqlSessionFactory;

import java.io.InputStream;

/**
 * Desription
 * 用于创建一个SqlSessionFactory对象
 * @author manno
 * @date 2020/9/26
 */
public class SqlSessionFactoryBuilder
{
    /**
     * @return SqlSessionFactory
     * @author manno
     * @date 2020/9/2
     * @param inputStream 参数的字节输入流
     * @description
     * 根据参数的字节输入流来创建一个SqlSessionFactory
     */
    public SqlSessionFactory build(InputStream inputStream)
    {
        Configuration cfg = XMLConfigBuilder.loadConfiguration(inputStream);
        System.out.println(cfg.toString());
        return new SqlSesssionFactoryImpl(cfg);
    }
}
