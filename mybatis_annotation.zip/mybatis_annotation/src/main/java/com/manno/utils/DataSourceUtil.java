package com.manno.utils;

import com.manno.mybatis.cfg.Configuration;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Desription
 * 用于获得Connection的工具类
 * @author manno
 * @date 2020/9/26
 */
public class DataSourceUtil
{
    public static Connection getConnection(Configuration cfg)
    {
        Connection connection = null;
        try
        {
            Class.forName(cfg.getDriver());
            connection =  DriverManager.getConnection(cfg.getUrl(),cfg.getUsername(),cfg.getPassword());
        } catch (ClassNotFoundException e)
        {
            e.printStackTrace();
        } catch (SQLException throwables)
        {
            throwables.printStackTrace();
        }
        return  connection;

    }
}
