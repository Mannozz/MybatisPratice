package com.manno.mybatis.session;

/**
 * Desription
 * SqlSession工厂类，生产SqlSession对象
 * @author manno
 * @date 2020/9/26
 */
public interface SqlSessionFactory
{
    /**
     * @author manno
     * @date 2020/9/2
     * @description
     * 用于打开一个新的SqlSession对象
     */
    SqlSession openSession();
}
