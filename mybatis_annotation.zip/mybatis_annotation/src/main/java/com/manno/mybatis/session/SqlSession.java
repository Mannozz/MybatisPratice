package com.manno.mybatis.session;

/**
 * Desription
 * 自定义mybatis中与数据库交互的核心类
 * 可以创建dao接口的代理对象
 * @author manno
 * @date 2020/9/26
 */
public interface SqlSession
{
    /**
     * @return dao代理对象
     * @author manno
     * @date 2020/9/2
     * @param daoInterfaceClass dao的接口字节码
     * @description
     * 根据参数创建一个代理对象
     */
    <T> T getMapper(Class<T> daoInterfaceClass) throws IllegalAccessException, InstantiationException;


    /**
     * @return a
     * @author manno
     * @date 2020/9/26
     * @description
     * 释放资源
     */
    void close();

}
