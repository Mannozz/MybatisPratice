package com.manno.mybatis.session.proxy;

import com.manno.mybatis.cfg.Mapper;
import com.manno.utils.Executor;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.util.Map;

/**
 * Desription
 * 自订的代理方法
 * @author manno
 * @date 2020/9/26
 */
public class MapperProxy implements InvocationHandler
{
//    map的KEY是全限定类名+方法名
    private Map<String, Mapper> mappers;//代理对象要实现的接口名单
    private Connection conn;

    public MapperProxy(Map<String,Mapper> mappers,Connection conn){
        this.mappers = mappers;
        this.conn = conn;
    }


    public Object invoke(Object proxy, Method method, Object[] args)
    {
        //获取方法名
        String methodName = method.getName();
        //获取方法所在类的名称
        String className = method.getDeclaringClass().getName();
        //组合KEY
        String key = className+"."+methodName;
        //获取Mapper对象
        Mapper mapper = mappers.get(key);
        if(mapper == null)
        {
            throw new IllegalArgumentException("传入的参数有误！");
        }
        System.out.println("生成的mapper对象为:"+mapper.toString());
        //调用工具类Executor执行查询所有
        return new Executor().selectList(mapper,conn);

    }
}
